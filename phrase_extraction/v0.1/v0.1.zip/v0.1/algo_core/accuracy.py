import csv
from testing import *


def run_all_data(ip_file, op_file, classifier):
    """
    :param ip_file:  read this file
    :param op_file: write to this file
    :param classifier: model to use

    get statistics regarding current accuracy of the model in predications
    also write data to csv files.
    """
    correct = 0
    total = 0

    with open(op_file, 'wb') as fw:
        writer = csv.writer(fw)
        writer.writerow(['text', 'target_phrase', 'observed_phrase', 'correctly_picked'])

        with open(ip_file, 'rU') as csvfile:
            reader = csv.reader(csvfile)
            for row in reader:
                _, sentence, phrase = row

                print '\nNew row', row

                try:
                    my_phrase = generate_phrases(sentence, classifier)
                    # print 'my_phrase:', my_phrase

                    if my_phrase == phrase.lower():
                        correct += 1
                        state = 'hit'
                    else:
                        state = 'miss'
                    total += 1

                    writer.writerow([sentence, phrase, my_phrase, state])
                except UnicodeDecodeError:
                    print 'unicode error!'

    print 'correct:', correct
    print 'total:', total
    print 'accuracy:', round(correct/float(total), 2)
    print 'done with writing results:', op_file


if __name__ == "__main__":

    # load classifier
    classifier = load_classifier()

    # file_name = 'training_80.csv'
    file_name = 'testing_20.csv'

    ip_file = '../data/' + file_name

    # write to op file
    op_file = '../results/processed_' + file_name

    run_all_data(ip_file, op_file, classifier)

