"""
similar to accuracy.py - just running for eval data
"""

from testing import *
import csv

if __name__ == "__main__":
    # read evaluation file
    file_name = 'eval_data.txt'

    ip_file = '../data/' + file_name

    # write to op file
    op_file = '../results/processed_eval_data.csv'

    # load classifier
    classifier = load_classifier()

    with open(op_file, 'wb') as fw:
        writer = csv.writer(fw)

        with open(ip_file) as f:
            for line in f:
                print '\nNew row:'
                try:
                    text = line.rstrip()
                    my_phrases = generate_phrases(text, classifier)
                    print 'my_phrases:', my_phrases
                    writer.writerow([text, my_phrases])
                except:
                    print 'unicode error!'

    print 'done with writing results'




