"""
build classifier based on enginnered features
"""

import csv
from get_patterns import get_pattern
import nltk
import pickle

if __name__ == "__main__":
    # read csv file
    ip_file = '../data/training_80.csv'

    training_set = []

    with open(ip_file, 'rU') as csvfile:
        reader = csv.reader(csvfile)
        for row in reader:
            print '\nNew row', row
            _, sentence, phrase = row

            if phrase == 'Not Found':
                continue

            try:
                features = get_pattern(sentence, phrase)
                training_set.extend(features)
            except:
                print 'unicode error'
                continue

    classifier = nltk.NaiveBayesClassifier.train(training_set)

    # save model
    save_classifier = open("../models/naivebayes.pickle", "wb")
    pickle.dump(classifier, save_classifier)
    save_classifier.close()