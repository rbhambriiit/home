"""
basic phrase generation workflow
perform sanity testing here...
all scripts in metrics folder will use this script

IDEALLY SHOULD BE CALLED prediction.py
"""

import pickle
import nltk

from nltk.util import ngrams


def generate_phrases(text, classifier):
    """
    :param text: input sentence
    :param classifier: trained Naive Bayes classifier model
    :return: predicted phrase
    """
    print 'input text', text
    tokens = nltk.word_tokenize(str(text).lower())
    pos_tags = nltk.pos_tag(tokens)

    my_phrases = []

    # try all phrase sizes
    for phrase_size in range(1, len(tokens)+1):
        prediction_workflow(pos_tags, phrase_size, my_phrases, classifier)

    if my_phrases:
        # found phrases. return last one - contains max data - basically sorting by size of text
        phrase = my_phrases[-1]
    else:
        phrase = 'not found'
    return phrase


def prediction_workflow(pos_tags, phrase_size, my_phrases, classifier):
    """
    :param pos_tags: POS tagging for sentence
    :param phrase_size: size of the phrase
    :param my_phrases: add all phrases selected to this list
    :param classifier: trained model
    :return: update list of my_phrases whenever a good phrase is predicted by the model
    """
    multi_grams = ngrams(pos_tags, phrase_size)

    for multi_gram in multi_grams:
        phrase_combination, pos_combination = zip(*list(multi_gram))
        pos_sequence = ' '.join(pos_combination)

        feature = {'pos_sequence': pos_sequence, 'size': phrase_size}
        predicted = classifier.classify(feature)
        if predicted:
            phrase_sequence = ' '.join(phrase_combination)
            print 'good phrase found:', phrase_sequence
            print 'phrase_size', phrase_size
            my_phrases.append(phrase_sequence)


def load_classifier():
    with open('../models/naivebayes.pickle', 'rb') as f:
        classifier = pickle.load(f)

    print 'Naive bayes classifier model loaded!'
    return classifier


if __name__ == "__main__":
    # load classifier
    classifier = load_classifier()

    text = "Can yu remind me to go to I.T computer class tommorow at 2PM?"
    # text = "Remind me to give Debit card to Preeanka."
    # text = "Remind me to buy cake today at 6:20 pm"
    # text = "Reminder to Apply for NET (Rekha)"

    my_phrases = generate_phrases(text, classifier)
    print 'final phrase:', my_phrases

