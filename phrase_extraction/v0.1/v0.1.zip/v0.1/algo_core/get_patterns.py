"""
feature engineering for text data
"""

import nltk
from nltk.util import ngrams


def get_pattern(sentence, phrase):
    """
    :param sentence: input sentence
    :param phrase: target phrase label in sentence
    :return my_features: list of features based on sentence structures - such as POS tagging

    """
    tokens = nltk.word_tokenize(str(sentence).lower())
    pos_tags = nltk.pos_tag(tokens)

    target_phrase_tokens = tuple(nltk.word_tokenize(str(phrase).lower()))
    size_selected = len(target_phrase_tokens)

    my_features = []

    multi_grams = list(ngrams(pos_tags, size_selected))
    for multi_gram in multi_grams:

        phrase_combination, pos_combination = zip(*list(multi_gram))

        pos_sequence = ' '.join(pos_combination)
        feature = {'pos_sequence': pos_sequence, 'size': size_selected}
        if phrase_combination == target_phrase_tokens:
            # print 'found candidate:', phrase_combination
            my_features.append((feature, 1))
        else:
            my_features.append((feature, 0))
    return my_features


if __name__ == "__main__":
    sentence = 'Remind me to take my salary slip at 3:30'
    phrase = 'take my salary slip'

    # sentence = 'remind me on 4th on second month to do hair spa time will be 6Pm.'
    # phrase = 'do hair spa time'

    features = get_pattern(sentence, phrase)
    for feature in features:
        print feature
